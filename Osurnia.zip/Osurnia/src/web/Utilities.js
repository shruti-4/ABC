'use strict';

/* eslint-disable no-var,quotes,import/no-extraneous-dependencies,global-require */
exports.createProxyAgent = function () {
  var proxyAgent;
  if (process.env.NODE_ENV === "development") {
    var HttpsProxyAgent = require('https-proxy-agent');
    // HTTP/HTTPS proxy to connect to
    var proxy = process.env.PROXY;
    console.log('Using proxy server: %s', proxy);
    // create an instance of the `HttpsProxyAgent` class with the proxy server information
    proxyAgent = new HttpsProxyAgent(proxy);
  }
  return proxyAgent;
};
exports.HomePage = function () {
  this.HomePageFormTitle = '';

};

exports.masterPageHeader = function () {
  this.HeaderLogo = '';

};
exports.masterPageFooter = function () {
  this.FooterPrivacyStatement = '';

};
