'use strict';

/* eslint-disable  no-unused-vars,no-undef,comma-dangle,prefer-arrow-callback*/
var util = require('util');
var utilities = require('../web/Utilities');
var express = require('express');

var router = express.Router();

exports.gethome = function (req, res, next) {
  cfClient.getEntries({
    content_type: 'body',
    locale: appLocale
  }).then(function (entries) {
    console.log(entries);
    if (entries.total !== 1) {
      var err = new Error('Error in fetching Home pages entry.');
      err.status = 404;
      next(err);
    }
    var content = new utilities.HomePage();
    var entry = entries.items[0];
    content.HomePageFormTitle = entry.fields.formtitle;
    global.gObjhomePage = content;
    res.render('index', {
      homePage: gObjhomePage
    });
  });
};
