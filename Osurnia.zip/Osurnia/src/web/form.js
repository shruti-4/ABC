/* eslint-disable no-unused-vars, vars-on-top, quotes,prefer-arrow-callback,
no-shadow,no-irregular-whitespace,prefer-template,consistent-return*/
const pg = require('pg');
const util = require('util');
const express = require('express');

const router = express.Router();
const xl = require('excel4node');
const date = require('date-and-time');
const moment = require('moment-timezone');

exports.saveData = function (req, res, next) {
  const config = {
    user: process.env.USER,
    database: process.env.DATABASE,
    password: process.env.PASSWORD,
    host: process.env.HOST,
    port: process.env.DATABASE_PORT,
    idleTimeoutMillis: 30000,
  };
  pg.defaults.ssl = true;
  const pool = new pg.Pool(config);
  const createTable = "CREATE TABLE osurnia_campaign" +
                                    "(" +
                                      "clinic_name character varying(50)," +
                                      "clinic_address character varying(50)," +
                                      "suburb character varying(50)," +
                                      "state_name character varying(20)," +
                                      "postcode character varying(30)," +
                                      "vat_name character varying(50)," +
                                      "email_address character varying(50)," +
                                      "preferred_wholeseller character varying(50)," +
                                      "phone character varying(13)," +
                                      "number_of_20_packs_required bigint," +
                                      "offer_required character varying(10)," +
                                      "date_ordered timestamp (6) with time zone" +
                                      ")";

  const insertQuery = "INSERT INTO " + process.env.DBTABLE + " (CLINIC_NAME,CLINIC_ADDRESS,SUBURB,STATE_NAME,POSTCODE,VAT_NAME,EMAIL_ADDRESS,PREFERRED_WHOLESELLER,PHONE,NUMBER_OF_20_PACKS_REQUIRED,OFFER_REQUIRED,DATE_ORDERED) VALUES('" + req.query.clinicName + "','"
      + req.query.clinicAddress + "','" + req.query.suburb + "','" + req.query.stateName + "','"
      + req.query.postCode + "','" + req.query.vatName + "','" + req.query.emailAddress + "','"
      + req.query.prefWs + "','" + req.query.phoneNo + "'," + req.query.noPack + ",'"
      + req.query.offers + "',current_timestamp)";

  pool.connect(function (err, client, done) {
    if (err) {
      return console.error('error fetching client from pool', err);
    }
    client.query(insertQuery, function (err, result) {
      done(err);
      if (err) {
        return console.error('error running query ', err);
      }
      res.send('Data Saved');
    });
  });
  pool.on('error', function (err, client) {
    console.error('idle client error', err.message, err.stack);
  });
};
