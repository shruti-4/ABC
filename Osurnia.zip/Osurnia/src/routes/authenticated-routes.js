// Routes in this module require authentication
/* eslint-disable no-unused-vars */
import express from 'express';

// Importing authentication flow
import auth from 'cirrus-auth-module';

// Importing the server side modules.
import testFile from '../server-controllers/test';

import home from '../web/index';
import saveData from '../web/form';

const router = express.Router();

// authenticate our router
auth.authenticate(router);

router.get('/', (req, res, next) => {
  home.gethome(req, res, next);
});

// index route
router.get('/index', (req, res, next) => {
  home.gethome(req, res, next);
});

router.get('/form', (req, res, next) => {
  if (req.query.clinicName === '') {
    next();
  } else if (req.query.ClinicAddress === '') {
    next();
  } else if (req.query.Suburb === '') {
    next();
  } else if (req.query.state === 'PLEASE SELECT') {
    next();
  } else if (req.query.PostCode === '') {
    next();
  } else if (req.query.VatName === '') {
    next();
  } else if (req.query.Email === '') {
    next();
  } else if (req.query.Wholesaler === 'PLEASE SELECT') {
    next();
  } else if (req.query.Phone === '') {
    next();
  } else if (req.query.NumberOfPacks === '') {
    next();
  } else if (req.query.privacy.checked === false) {
    next();
  } else {
    saveData.saveData(req, res, next);
  }
});
module.exports = router;
