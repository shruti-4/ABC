epository Name: Elanco_Osurnia_OrderingPage
Application Short Name: Elanco_Osurnia_OrderingPage
Repository Owner: RASHMI SETHI (C232433)
Responsible IT Organization: Elanco  IT
Development Languages: Node.js
