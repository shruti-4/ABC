/*var contentful = require('contentful');
var util = require('util');

var client = contentful.createClient({
  // This is the space ID. A space is like a project folder in Contentful terms
  space: 'fms9kqpqz9n5',
  // This is the access token for this space. Normally you get both ID and the token in the Contentful web app
  accessToken: 'c6b65c006796129cbc5692d564a8afde0ff7668c99a0d8680af8eed3eda9e388'
});

client.getEntry('46nPDoQhdxcRiMwiSb7nJI')
.then(function (entry) {
  console.log(util.inspect(entry, {depth: null}));
});
*/
var contentful = require('contentful-management')
var client = contentful.createClient({
  // This is the access token for this space. Normally you get the token in the Contentful web app
  accessToken: 'c6b65c006796129cbc5692d564a8afde0ff7668c99a0d8680af8eed3eda9e388'
});

// This API call will request a space with the specified ID
client.getSpace('fms9kqpqz9n5')
.then((space) => {
  // Now that we have a space, we can get entries from that space
  space.getEntries()
  .then((entries) => {
    console.log(entries.items)
  });
});
